MVC Application:
	To run the MVC Application, start the MealCostController.py python file. This will require python to be installed or require the use of a 
	python IDE

MVP Application:
	To run the MVP Application, MainActivity.java must be run. This will require the installation of android studio and a phone from it's
	AVD Manager. The phone used to test the application was a Nexus 5 API 29.